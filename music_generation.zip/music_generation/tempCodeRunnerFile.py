6import numpy as np
from music21 import note, stream
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense
from tensorflow.keras.utils import to_categorical


# ---------------------------------------
# 1. CREATE SIMPLE MUSIC DATA
# ---------------------------------------

notes = [
    "C4", "D4", "E4", "F4",
    "G4", "A4", "B4", "C5",
    "B4", "A4", "G4", "F4",
    "E4", "D4", "C4"
]


# Convert notes into numbers
unique_notes = sorted(set(notes))

note_to_int = {
    note_name: number
    for number, note_name in enumerate(unique_notes)
}

int_to_note = {
    number: note_name
    for number, note_name in enumerate(unique_notes)
}


encoded_notes = [
    note_to_int[note_name]
    for note_name in notes
]


# ---------------------------------------
# 2. CREATE TRAINING SEQUENCES
# ---------------------------------------

sequence_length = 4

X = []
y = []

for i in range(len(encoded_notes) - sequence_length):

    sequence = encoded_notes[
        i:i + sequence_length
    ]

    target = encoded_notes[
        i + sequence_length
    ]

    X.append(sequence)
    y.append(target)


X = np.array(X)
y = np.array(y)


# ---------------------------------------
# 3. ONE-HOT ENCODING
# ---------------------------------------

number_of_notes = len(unique_notes)

y = to_categorical(
    y,
    num_classes=number_of_notes
)


# Reshape input for LSTM
X = X.reshape(
    X.shape[0],
    X.shape[1],
    1
)

X = X / float(number_of_notes)


# ---------------------------------------
# 4. BUILD LSTM MODEL
# ---------------------------------------

model = Sequential()

model.add(
    LSTM(
        128,
        input_shape=(
            X.shape[1],
            X.shape[2]
        )
    )
)

model.add(
    Dense(
        number_of_notes,
        activation="softmax"
    )
)


model.compile(
    loss="categorical_crossentropy",
    optimizer="adam"
)


print("\nTraining AI Music Model...\n")


# ---------------------------------------
# 5. TRAIN MODEL
# ---------------------------------------

model.fit(
    X,
    y,
    epochs=100,
    batch_size=2,
    verbose=1
)


# ---------------------------------------
# 6. GENERATE MUSIC
# ---------------------------------------

print("\nGenerating music...\n")


start_sequence = encoded_notes[:sequence_length]

generated_notes = []


for i in range(20):

    input_sequence = np.array(
        start_sequence
    ).reshape(
        1,
        sequence_length,
        1
    )

    input_sequence = (
        input_sequence /
        float(number_of_notes)
    )

    prediction = model.predict(
        input_sequence,
        verbose=0
    )

    predicted_index = np.argmax(
        prediction
    )

    predicted_note = int_to_note[
        predicted_index
    ]

    generated_notes.append(
        predicted_note
    )

    start_sequence.append(
        predicted_index    )

    start_sequence = start_sequence[
        1:
    ]


# ---------------------------------------
# 7. CREATE MIDI FILE
# ---------------------------------------

music = stream.Stream()


for note_name in generated_notes:

    new_note = note.Note(note_name)

    new_note.quarterLength = 1

    music.append(new_note)


music.write(
    "midi",
    fp="generated_music.mid"
)


print(
    "\nMusic generated successfully!"
)

print(
    "File saved as: generated_music.mid"
)